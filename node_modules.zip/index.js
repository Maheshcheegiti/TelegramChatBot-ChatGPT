const TelegramBot = require("node-telegram-bot-api");
const {
    Configuration,
    OpenAIApi
} = require("openai");


const token = '6220811250:AAFw7W0h2NgNXhVi9TKR6TVSwzZAsJ1hEqM';
const chatGptToken = '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';

const configuration = new Configuration({
    apiKey: chatGptToken,
});

const openai = new OpenAIApi(configuration)

const bot = new TelegramBot(token, {
    polling: true
});

bot.on("message", async function (msg) {
    const chatId = msg.chat.id;
    const userInput = msg.text;

    const response = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: userInput,
        temperature: 0,
        max_tokens: 3000,
        top_p: 1,
        frequency_penalty: 0.5,
        presence_penalty: 0,
    });
    const generatedText = response.data.choices[0].text;

    bot.sendMessage(chatId,generatedText);
});